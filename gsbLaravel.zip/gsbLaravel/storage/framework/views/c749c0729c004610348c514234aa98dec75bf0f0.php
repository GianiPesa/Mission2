
    <?php $__env->startSection('contenu2'); ?>
        
  <?php $__env->stopSection(); ?> 
 
<?php echo $__env->make('listeVisiteurs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\x\Desktop\laragon\www\gsbLaravelv2\gsbLaravel\resources\views/supprimer.blade.php ENDPATH**/ ?>