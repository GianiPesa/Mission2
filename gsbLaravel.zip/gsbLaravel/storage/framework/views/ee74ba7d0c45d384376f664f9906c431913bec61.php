    <?php $__env->startSection('menu'); ?>
            <!-- Division pour le sommaire -->
        <div id="menuGauche">
            <div id="infosUtil">
                  
             </div>  
               <ul id="menuList">
                   <li >
                    <strong>Bonjour <?php echo e($admin['nom'] . ' ' . $admin['prenom']); ?></strong>
                      
                   </li>
             
                  
                  <li class="smenu">
                    <a href="<?php echo e(route('chemin_listerVisiteurs')); ?>" title="Supp">Supprimer</a>
                  </li>
               <li class="smenu">
                <a href="<?php echo e(route('chemin_deconnexion')); ?>" title="Se déconnecter">Déconnexion</a>
                  </li>
                </ul>
               
        </div>
    <?php $__env->stopSection(); ?>          
<?php echo $__env->make('modeles/visiteur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\gsbLaravelv2\gsbLaravel\resources\views/sommaireAdmin.blade.php ENDPATH**/ ?>