
 <?php $__env->startSection('contenu1'); ?>
 <h1>Suppression Reussi</h1>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('sommaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\gsbLaravelv2\gsbLaravel\resources\views/supprimer.blade.php ENDPATH**/ ?>