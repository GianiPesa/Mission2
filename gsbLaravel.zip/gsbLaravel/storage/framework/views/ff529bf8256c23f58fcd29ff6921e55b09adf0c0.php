
    <?php $__env->startSection('contenu1'); ?>
      <div id="contenu">
        <h2>Mes fiches de frais</h2>
        <h3>Visiteurs : </h3>
      <form action="<?php echo e(route('chemin_listerVisiteurs')); ?>" method="post">
        <?php echo e(csrf_field()); ?> <!-- laravel va ajouter un champ caché avec un token -->
        <div class="corpsForm"><p>

          <label for="lstVisiteurs" accesskey="n">Visiteurs : </label>
          <select id="lstVisiteurs" name="lstVisiteurs">
              <?php $__currentLoopData = $lesVisiteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unVisiteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option type="text" value="<?php echo $unVisiteur['id']; ?>"><?php echo $unVisiteur['id'] ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </p>
        </div>
          <input id="ok" type="submit" value="Valider" size="20" />
          <input id="annuler" type="reset" value="Effacer" size="20" />
        </form>
  <?php $__env->stopSection(); ?> 

<?php echo $__env->make('sommaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\laragon\www\gsbLaravel\resources\views/listeVisiteurs.blade.php ENDPATH**/ ?>