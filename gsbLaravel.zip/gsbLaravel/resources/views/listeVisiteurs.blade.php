@extends ('sommaireAdmin')
    @section('contenu1')
      <div id="contenu">
        <h2>Mes fiches de frais</h2>
        <h3>Visiteurs : </h3>
      <form action="{{ route('chemin_archivage') }}" method="post">
        {{ csrf_field() }} <!-- laravel va ajouter un champ caché avec un token -->
        @includeWhen($erreurs != null , 'msgerreurs', ['erreurs' => $erreurs]) 
        <div class="corpsForm"><p>
        <!-- Récuperation de l'id, et Création de la liste déroulante -->
          <label for="lstVisiteurs" accesskey="n">Visiteurs : </label>
          <select id="lstVisiteurs" name="lstVisiteurs">
              @foreach($lesVisiteurs as $unVisiteur)
              <?php $id = $unVisiteur['id']; ?>
              <option type="text" value="<?php echo $id; ?>">
              <?php echo $id ?>
              <?php echo $unVisiteur['prenom'] ?>
              <?php echo $unVisiteur['nom'] ?></option></option>
              
              @endforeach
          </select>
        </p>
        </div>
          <input id="ok" type="submit" value="Valider" size="20" />
          <input id="annuler" type="reset" value="Effacer" size="20" />
        </form>
  @endsection 
