@extends ('sommaire')
 @section('contenu1')
 <h1>Suppression Reussi</h1>
 @endsection