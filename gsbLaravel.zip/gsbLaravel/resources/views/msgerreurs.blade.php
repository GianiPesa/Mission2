<div class ="erreur">
    <ul>
        @foreach($erreurs as $erreur)
            <li>{{ $erreur }}</li>
        @endforeach
    </ul>
</div>