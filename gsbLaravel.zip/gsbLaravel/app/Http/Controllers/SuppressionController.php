<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoGsb;
use MyDate;
class SuppressionController extends Controller
{
    function voirEtatVisiteur(Request $request){
        if(session('admin') != null){
            $admin = session('admin');
            // liste déroulante ou on récupère l'id
            $lesVisiteurs=PdoGsb::getLesVisiteurs();
            $lesCles = array_keys( $lesVisiteurs );
            $visiteursASelectionner = $lesCles[0];
            return view('listeVisiteurs')
                        ->with('lesVisiteurs', $lesVisiteurs)
                        ->with('admin',$admin)
                        ->with('erreurs',null);
            }
            else{
              return view('connexion')->with('erreurs',null);
          }
        
    }

    function archivage(Request $request){
        if(session('admin') != null){
            // On récupère l'id de l'utilisateur qui vas etre supprimer
            $id = $request['lstVisiteurs'];
            // Archivage de toutes les données supprimer
            PdoGsb::insertArchivageVisiteur($id);
            PdoGsb::insertArchivageFicheFrais($id);
            PdoGsb::insertArchivageLigneFraisForfait($id);
            PdoGsb::insertArchivageLigneFraisHorsForfait($id);
            // Suppression de toutes les données concernant l'utilisateur dont l'id est passer en parametre
            PdoGsb::deleteLigneFraisForfait($id);
            PdoGsb::deleteFicheFrais($id);
            PdoGsb::deleteLigneFraisHorsForfait($id);
            PdoGsb::deleteVisiteur($id);
            // Re afficher la vue et affichage du msg de supression reussie 
            $admin = session('admin');
            $lesVisiteurs=PdoGsb::getLesVisiteurs();
            $lesCles = array_keys( $lesVisiteurs );
            $visiteursASelectionner = $lesCles[0];
            $message[] = "Suppression reussie !";
            return view('listeVisiteurs')
                        ->with('lesVisiteurs', $lesVisiteurs)
                        ->with('admin',$admin)
                        ->with('erreurs',$message);
        
}
else{
  return view('connexion')->with('erreurs',null);
}

    
    }
    

}